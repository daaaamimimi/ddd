include(joinpath(@__DIR__, "CEI_ILD.jl"))
using .CEI_ILD

# ===================== 1. 参数 =====================
# 56G NRZ 若实际是 56 Gb/s，则这里是 56e9，而不是 28e9。
# 若实际线速为 53.125 Gb/s，则改成 53.125e9。
# 此示例的频段/9 ps/无系数边界为工程配置，不能当作核实后的标准参数。
cfg = engineering_settings(fb_hz=56e9)

# 按手头实际草案修改参数：
# cfg = merge(cfg, (
#     coeff_min=(你的a0下限, 你的a1下限, 你的a2下限, 你的a4下限),
#     coeff_max=(你的a0上限, 你的a1上限, 你的a2上限, 你的a4上限),
#     fom_limit_db=你的限值,
#     profile_name="填写草案版本、条款号、测试参考平面",
# ))

# ===================== 2. 合成数据演示 =====================
# 不依赖 S4P 解析器；用这段确认计算链和输出接口。
f_hz = collect(0.0:10e6:56e9)
x = f_hz ./ cfg.fb_hz
il_base = 0.2 .+ 5.0 .* sqrt.(x) .+ 7.0 .* x .+ 2.0 .* x.^2
ripple = 0.35 .* sin.(2pi .* f_hz ./ 6e9)
il_db = il_base + ripple
sdd21 = 10.0 .^ (-il_db ./ 20) .* cis.(-2pi .* f_hz .* 80e-12)

r = cei_ild(f_hz, sdd21; cfg...)
print_ild_summary(r)
paths = write_ild_csv(joinpath(@__DIR__, "output", "synthetic_demo"), r)
println("\nExported: ", paths)

# ===================== 3. S4P 读取接口 =====================
# 真实数据使用方法（用你自己的读取库完成 my_reader 后取消注释）：
#
# function my_reader(path::AbstractString)
#     # 在这里读取文件，解析单位/格式/参考阻抗，并整理维度。
#     # 返回：f_hz::Vector、S::Array(4,4,N)、z0_ohm::Number 或四元素向量
#     # 不要把 dB/相位对直接塞进 S；必须先转换为线性复数。
#     return (f_hz=f_hz, S=S, z0_ohm=z0_ohm)
# end
#
# real_result = cei_ild_s4p(raw"D:\data\channel.s4p";
#     reader=my_reader,
#     input_pair=(1,2),    # 这里示例为输入P=1，输入N=2；必须按实际连接修改
#     output_pair=(3,4),   # 输出P=3，输出N=4
#     cfg...)
# print_ild_summary(real_result)
# write_ild_csv(joinpath(@__DIR__, "output", "channel"), real_result)
#
# 对于端口顺序 [输入P,输出P,输入N,输出N]：
# input_pair=(1,3), output_pair=(2,4)
#
# 若已有 f_hz 和 S，可直接用：
# r = cei_ild_sparams(f_hz, S;
#     input_pair=(1,2), output_pair=(3,4), z0_ohm=50.0, cfg...)
#
# 数据覆盖完整频段但端点不对齐/非均匀：显式对 IL(dB) 插值。
# cfg_interp = merge(cfg, (grid_mode=:linear_il, df_hz=10e6))
# r = cei_ild(f_hz, sdd21; cfg_interp...)
