using Test
using LinearAlgebra
include(joinpath(@__DIR__, "CEI_ILD.jl"))
using .CEI_ILD

cfg = engineering_settings()
f = collect(0.0:10e6:56e9)
x = f ./ cfg.fb_hz
X = hcat(ones(length(f)), sqrt.(x), x, x.^2)
true_a = [0.2, 5.0, 7.0, 2.0]
y = X * true_a
h = 10.0 .^ (-y ./ 20) .* cis.(-2pi .* f .* 80e-12)

@testset "Exact fitted channel" begin
    r = cei_ild(f, h; cfg...)
    @test r.fom_ild_db < 1e-10
    @test collect(values(r.coefficients)) ≈ true_a atol=1e-9
    @test r.n_fit == 5596
    @test r.n_fom == 4196
    @test ismissing(r.meets_user_limit)
    @test !r.bounds_applied
    @test !r.coarse_sampling
    @test last(r.f_fit_hz) == 56e9
    @test last(r.f_fom_hz) == 42e9
end

@testset "Weighting and loss inputs" begin
    yr = y + 0.35 .* sin.(2pi .* f ./ 6e9)
    hr = 10.0 .^ (-yr ./ 20) .* cis.(-2pi .* f .* 80e-12)
    r = cei_ild(f, hr; cfg...)
    r_db = cei_ild_from_il(f, yr; cfg...)
    @test r.fom_ild_db ≈ r_db.fom_ild_db atol=1e-12
    @test r.fom_ild_db ≈ sqrt(sum(r.weights .* r.ild_fom_db.^2)/r.n_fom)
    @test last(r.cumulative_fom_db) ≈ r.fom_ild_db
    @test r.fom_ild_db < r.ild_rms_unweighted_db
    @test r.settings.ft_hz ≈ 0.2365/9e-12
    @test all((0 .<= r.weights) .& (r.weights .<= 1))
    @test cei_ild(f, hr; merge(cfg,(fom_limit_db=10.0,))...).meets_user_limit
    @test !cei_ild(f, hr; merge(cfg,(fom_limit_db=0.0,))...).meets_user_limit
end

@testset "Mixed-mode mapping, polarity and reader hook" begin
    S = zeros(ComplexF64, 4, 4, length(f))
    S[3,1,:] .= h; S[4,2,:] .= h
    S[1,3,:] .= h; S[2,4,:] .= h
    @test sdd21_from_sparams(S; input_pair=(1,2), output_pair=(3,4), z0_ohm=50) ≈ h
    @test sdd21_from_sparams(S; input_pair=(1,2), output_pair=(4,3), z0_ohm=50) ≈ -h
    r = cei_ild_sparams(f, S; input_pair=(1,2), output_pair=(3,4), z0_ohm=50, cfg...)
    @test r.fom_ild_db < 1e-10
    # 新顺序 [输入P,输出P,输入N,输出N]
    p = [1,3,2,4]
    S2 = S[p,p,:]
    @test sdd21_from_sparams(S2; input_pair=(1,3), output_pair=(2,4), z0_ohm=50) ≈ h
    reader = path -> (f_hz=f, S=S, z0_ohm=50.0)
    rr = cei_ild_s4p("synthetic-not-a-real-file.s4p"; reader=reader,
        input_pair=(1,2), output_pair=(3,4), cfg...)
    @test rr.fom_ild_db ≈ r.fom_ild_db
    @test_throws ArgumentError read_s4p("not-implemented.s4p")
    @test_throws ArgumentError sdd21_from_sparams(S; input_pair=(1,2), output_pair=(3,4), z0_ohm=75)
    @test_throws ArgumentError sdd21_from_sparams(S; input_pair=(1,2), output_pair=(2,4), z0_ohm=50)
end

@testset "Sequential coefficient fixing and refitting" begin
    # 人工上下限只用于算法测试，不是 56G-VSR-NRZ 参数。
    cc = merge(cfg, (coeff_min=(-1.0,0.0,0.0,0.0), coeff_max=(2.0,20.0,20.0,20.0)))
    yn = X * [0.2,5.0,7.0,-0.5]
    r = cei_ild_from_il(f, yn; cc...)
    @test r.coefficients.a4 == 0.0
    @test first(r.fit_history).coefficient == :a4
    @test first(r.fit_history).side == :lower
    idx = f .>= 50e6
    A3 = X[idx,1:3]
    g = 10.0 .^ (-yn[idx] ./ 20)
    expected = (A3 .* reshape(g,:,1)) \ (yn[idx] .* g)
    @test collect(values(r.coefficients))[1:3] ≈ expected atol=1e-9
    # 同时下限越界时优先固定 a4。
    yp = X * [1.0,-0.1,10.0,-0.1]
    rp = cei_ild_from_il(f, yp; cc...)
    @test first(rp.fit_history).coefficient == :a4
    # 仅 a0 上限越界；其他边界保持无穷。
    cu = merge(cfg, (coeff_min=nothing, coeff_max=(0.1,Inf,Inf,Inf)))
    ru = cei_ild_from_il(f, y; cu...)
    @test ru.coefficients.a0 == 0.1
    @test first(ru.fit_history).side == :upper
end

@testset "Grid handling and bad input" begin
    hc = copy(h); hc[1] = 0
    @test cei_ild(f, hc; cfg...).fom_ild_db < 1e-10  # DC 不参与计算
    @test_throws ArgumentError cei_ild(f[1:end-1], h[1:end-1]; cfg...) # 覆盖不足
    @test_throws ArgumentError cei_ild(reverse(f), reverse(h); cfg...)
    @test_throws ArgumentError cei_ild(f, h; merge(cfg,(tr_s=0.0,))...)
    @test_throws DimensionMismatch cei_ild(f[1:end-1], h; cfg...)
    bad = copy(h); bad[10] = 0
    @test_throws ArgumentError cei_ild(f, bad; cfg...)
    # 原数据不等间隔，但最大间隔仍小于 10 MHz。
    fj = collect(0.0:5e6:56e9)
    fj[2:end-1] .+= 0.5e6 .* sin.(collect(2:(length(fj)-1)))
    # 线性 IL 插值应精确恢复线性 IL 曲线。
    yj = 0.2 .+ 10.0 .* (fj ./ cfg.fb_hz)
    ri = cei_ild_from_il(fj, yj; merge(cfg,(grid_mode=:linear_il,))...)
    @test ri.fom_ild_db < 1e-10
    @test !ri.coarse_sampling
    fc = collect(0.0:20e6:56e9)
    yc = 0.2 .+ 10.0 .* (fc ./ cfg.fb_hz)
    @test_throws ArgumentError cei_ild_from_il(fc, yc; merge(cfg,(grid_mode=:linear_il,))...)
    # 非整 10 MHz 的线速，由插值模式确保两端点均包含。
    cfg53 = merge(engineering_settings(fb_hz=53.125e9), (grid_mode=:linear_il,))
    r53 = cei_ild_from_il(f, y; cfg53...)
    @test last(r53.f_fit_hz) == 53.125e9
    @test last(r53.f_fom_hz) == 0.75 * 53.125e9
end

@testset "Exports" begin
    mktempdir() do d
        r = cei_ild(f, h; cfg...)
        p = write_ild_csv(joinpath(d,"check"), r)
        @test all(isfile, values(p))
        @test length(readlines(p.fit_csv)) == r.n_fit + 1
        @test length(readlines(p.fom_csv)) == r.n_fom + 1
    end
end
