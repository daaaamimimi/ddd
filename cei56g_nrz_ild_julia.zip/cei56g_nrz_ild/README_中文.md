# CEI ILD / FOM：Julia 工程计算工具

面向你的 **56G NRZ VSR** 数据处理流程；S4P 解析器按要求只留接口。
计算模块仅使用 Julia 标准库 `LinearAlgebra` 和 `Printf`。

## 先说明适用边界

已核对 OIF-CEI-05.2 的通用插损拟合方法（§12.2.1.1），以及
§14.2.6.4 中的 ILD/FOM 数学表达式。**§14 的接口是 28G-MR，
不能把其中的参数表直接当作 56G-VSR-NRZ 参数表。**

公开 OIF-CEI-05.2 的 §15 是保留页。Keysight 的 N109256CB
测试方法文档将 56G-VSR-NRZ 指向 OIF2014.277.09；本次未取得该草案的
完整 ILD/FOM 参数定义。因此本工具提供的是可配置的计算算法，
**不包含已核实的 56G-VSR-NRZ 合规预设**。

`engineering_settings()` 是可运行示例，不是标准认证配置。
默认系数边界为 `nothing`（不施加边界），限值为 `nothing`（不做限值判断）。
若真实草案要求系数边界，无边界结果可能不同，不能直接作合规报告。

## 文件

| 文件 | 用途 |
|---|---|
| `CEI_ILD.jl` | 核心计算、混合模转换、S4P 回调接口、CSV 导出 |
| `example.jl` | 合成通道演示、真实数据接入示例 |
| `runtests.jl` | Julia 自测：零偏差、纹波、约束重拟合、端口映射、频率检查等 |
| `NUMERICAL_CHECK.txt` | 独立 Python 数值对照记录；不是 Julia 执行记录 |

本次环境没有 Julia 运行时，且运行时下载失败，**未执行 Julia 文件**。
已用独立 Python/NumPy 计算完成 22 项数学/数据映射对照。
请在本地先运行自测；代码未与商业仪器做逐点一致性验证。

## 1. 运行演示

终端切换到解压目录，执行：

```text
julia runtests.jl
julia example.jl
```

或者在 Julia REPL 中：

```julia
include(raw"D:\your_folder\cei56g_nrz_ild\example.jl")
```

演示会生成 `output/synthetic_demo_fit.csv`、`output/synthetic_demo_fom.csv`
以及 `output/synthetic_demo_summary.txt`。

工程示例的独立 Python 参考数值：

```text
FOM_ILD                ≈ 0.166218047286 dB
非加权 ILD RMS         ≈ 0.245074011810 dB
拟合点数                = 5596
FOM 点数                = 4196
```

这些数值来自 `example.jl` 定义的合成纹波通道，不是你的实测结果，
也不能解释为 CEI 合规结论。

## 2. 配置

```julia
include("CEI_ILD.jl")
using .CEI_ILD

cfg = engineering_settings(fb_hz=56e9)
```

工程示例值如下，**使用前应按实际草案核对**：

| 参数 | 工程示例值 | 含义 |
|---|---:|---|
| `fb_hz` | `56e9` | 符号率；56 Gb/s NRZ 对应 56 GBd，不除以 2 |
| `ffit_min_hz` | `50e6` | 拟合起点 |
| `ffit_max_hz` | `56e9` | 拟合终点 |
| `ffom_min_hz` | `50e6` | FOM 起点 |
| `ffom_max_hz` | `42e9` | FOM 终点 |
| `tr_s`, `tf_s` | `9e-12` | 20%–80% 参考上升/下降时间的示例值 |
| `fr_hz` | `42e9` | 参考接收滤波器带宽示例值 |
| `coeff_min/max` | `nothing` | 系数边界未设置，不冒用其他接口的边界 |
| `fom_limit_db` | `nothing` | 不自动套用 0.3 dB 或其他限值 |
| `grid_mode` | `:strict` | 严格检查原始等间隔频点 |

`ft_hz = 0.2365 / min(tr_s, tf_s)`，用当前示例得到 26.2777777778 GHz。
9 ps 可在 Keysight 引述的 NRZ 模块输出转变时间要求中看到，但这不足以单独证明
它就是你采用版本的通道 FOM 参考边沿。应核对具体 FOM 定义及测试参考平面。

修改已有配置时使用 `merge`，避免重复关键字：

```julia
cfg = merge(cfg, (
    grid_mode=:linear_il,
    df_hz=10e6,
    profile_name="填写实际草案版本、条款和参考平面",
))
```

系数边界的顺序始终是 **(a0, a1, a2, a4)**，不是 a0、a1、a2、a3。
实际线速为 53.125 Gb/s NRZ 时使用 `engineering_settings(fb_hz=53.125e9)`，
并按实际数据的端点对齐情况选择网格模式。

## 3. 已有 Sdd21：直接计算

```julia
# f_hz: 长度 N 的实数频率，单位 Hz
# sdd21: 长度 N 的线性复数差分传输参数，不是 dB/相位对
r = cei_ild(f_hz, sdd21; cfg...)
print_ild_summary(r)
```

已有正损耗 IL(dB) 时：

```julia
r = cei_ild_from_il(f_hz, il_db; cfg...)
```

如果已有的是通常为负数的 `20*log10(abs(Sdd21))`，应先取负号得到 `il_db`。
不要把 dB 数值传给 `cei_ild` 的线性 Sdd21 输入。

## 4. 已有单端四端口 S 参数

```julia
r = cei_ild_sparams(f_hz, S;
    input_pair=(1,2),
    output_pair=(3,4),
    z0_ohm=50.0,
    cfg...)
```

约定：`S` 为 `4×4×N` 的线性复数数组，
`S[接收端口, 激励端口, 频点]`。端口从 1 开始编号。

对于端口顺序 `[输入P, 输入N, 输出P, 输出N]`：

```julia
input_pair=(1,2)
output_pair=(3,4)
```

对于端口顺序 `[输入P, 输出P, 输入N, 输出N]`：

```julia
input_pair=(1,3)
output_pair=(2,4)
```

函数计算：

```text
Sdd21 = (S[输出P,输入P] - S[输出P,输入N]
       - S[输出N,输入P] + S[输出N,输入N]) / 2
```

必须先对复数 S 参数做上述相加减，再求幅度和 dB，不能先对单端项取绝对值。
当前接口只接收四个单端端口均为实数 50 ohm 参考阻抗的数据；
其他参考阻抗应在读取端正确重归一化，不会在计算模块内静默处理。
已经是混合模的数据不要再次进行单端到差分转换。

## 5. S4P 读取接口

`read_s4p()` 目前有意抛出“接口未接入”错误，不会伪装成已读取文件。
完成你自己的读取函数后，用 `reader` 参数传入：

```julia
function my_reader(path::AbstractString)
    # 你的读取程序。
    # f_hz: Vector{Float64}
    # S:    Array{ComplexF64,3}, size(S) == (4,4,length(f_hz))
    # z0_ohm: 真实文件的参考阻抗，标量或四元素向量
    return (f_hz=f_hz, S=S, z0_ohm=z0_ohm)
end

r = cei_ild_s4p(raw"D:\data\channel.s4p";
    reader=my_reader,
    input_pair=(1,2),
    output_pair=(3,4),
    cfg...)
```

解析器负责频率单位、RI/MA/DB、角度制、Touchstone 数据顺序、参考阻抗及
单端/混合模标记。不要无条件把参考阻抗写成 50。

## 6. 计算细节

拟合基函数：`[1, sqrt(f/fb), f/fb, (f/fb)^2]`。
行乘子是 `g=10^(-IL/20)`；求解 `(X .* g) \ (IL .* g)`，
即残差平方的权重为 `|Sdd21|^2`。固定系数后用原始测量权重重新拟合，
不会把新残差误当成新的插损来重算权重。

约束启用时每次只固定一个越界系数，同类越界按 a4、a1、a2、a0 顺序处理，
先检查下限，再检查上限；上限重拟合后也复查新出现的下限越界。
`fit_history` 返回每次固定的系数、边界方向和数值。这不是通用最优化器的
盒约束最小二乘，也不是一次无约束拟合后简单截断。

```text
ILD(f) = IL(f) - ILfit(f)

W(f) = sinc(f/fb)^2 / [1+(f/ft)^4] / [1+(f/fr)^8]

FOM_ILD = sqrt(sum(W .* ILD.^2) / N_FOM)
```

Julia 的 `sinc(x)` 为 `sin(pi*x)/(pi*x)`，不用再给参数乘 pi。
分母是 FOM 频点数，不是权重之和；权重只乘一次。

拟合必须使用完整拟合频段，而不是只用 FOM 频段。
严格模式要求原数据覆盖且包含两组频段端点、频率等间隔、间隔不大于 10 MHz。
`:linear_il` 模式只对 IL(dB) 进行线性插值，不直接对有长时延相位旋转的复数 S21
做线性插值；拟合和 FOM 各自建立包含端点的均匀网格。

**把 100 MHz 原数据插值成 10 MHz，不等于满足原始采样要求。**
原始/计算间隔大于 10 MHz 时默认报错。`allow_coarse=true` 仅允许工程预览，
并发出警告，不会恢复漏测的窄带纹波。

DC 零传输允许存在，只要不进入被使用的拟合/FOM 频段。
频段内零传输、NaN、Inf、频率重复或覆盖不足会报错，避免静默给出错误结果。

## 7. 结果

```julia
r.fom_ild_db                    # 加权 FOM，dB
r.ild_rms_unweighted_db         # 同一 FOM 频段内，未加权 RMS
r.coefficients                 # (a0=..., a1=..., a2=..., a4=...)
r.fit_history                  # 约束固定/重拟合记录
r.f_fit_hz                     # 拟合频率网格
r.il_db                        # 正插损
r.il_fit_db                    # 拟合插损
r.ild_db                       # 完整拟合频段内的 ILD
r.f_fom_hz                     # FOM 频率网格
r.ild_fom_db                   # FOM 频段内的 ILD
r.weights                      # FOM 权重 W
r.meets_user_limit             # 未设限值时为 missing
```

`meets_user_limit` 使用 `<=`，仅表示给定数值限值下的比较。
若实际条款要求严格 `<`，应按条款另行比较。
即使 FOM 满足限值，也不表示其他插损、回损、模式转换、串扰及眼图指标均合格。

## 参考资料

- OIF-CEI-05.2：§12.2.1.1（PDF 第 269–271 页），§14.2.6.4（第 311–312 页），
  §15 保留页（第 325 页）。
- Keysight N109256CB OIF CEI 56G Test Software MOI，版本 2.0.26.0：
  56G-VSR-NRZ 测量引用 OIF2014.277.09。
- Julia 官方 LinearAlgebra 文档及 sinc 定义。

```text
https://www.oiforum.com/wp-content/uploads/OIF-CEI-05.2.pdf
https://www.keysight.com/sk/en/assets/9921-02554/reference-guides/N109256CB-OIF-CEI-56G-Test-Software-MOI-2-0-26-0.pdf
https://docs.julialang.org/en/v1/stdlib/LinearAlgebra/
https://docs.julialang.org/en/v1/base/math/#Base.Math.sinc
```
